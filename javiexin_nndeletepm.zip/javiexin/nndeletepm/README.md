# No notice on unread deleted PMs

## Installation

Copy the extension to phpBB/ext/javiexin/nndeletepm

Go to "ACP" > "Customise" > "Extensions" and enable the "No Notice Delete PM" extension.

## License

[GPLv2](license.txt)
